# Issue closing pattern

By default you can close issues from commit messages by saying 'Closes #12' or 'Fixed #101'.

If you want to customize the message please do so in [gitlab.yml](https://gituse.com/gitlab-org/gitlab-ce/blob/73b92f85bcd6c213b845cc997843a969cf0906cf/config/gitlab.yml.example#L73)
