#文档

##用户文档

- [API](api/README.md)，通过一个简单而功能强大的API自动GitLab。
- [降价](markdown/markdown.md)GitLab先进格式化系统。
- [权限](permissions/permissions.md)了解什么是在一个项目（客户/本报记者/开发/主/所有者)，每个角色都可以做到。
- [工程服务](project_services/project_services.md)整合与外部服务，如CI和聊天的项目。
- [公共访问](public_access/public_access.md)，了解如何才能让公众和内部访问项目。
- [SSH](ssh/README.md)设置您的SSH密钥和部署到你的项目的安全访问键。
- [网络钩](web_hooks/web_hooks.md)让GitLab通知您，当新的代码已经被推到项目中。
- [工作流程](workflow/README.md)了解如何获得最大的出GitLab的。

##管理员文档

- [安装](install/README.md)的要求，目录结构和手动安装。
- [综合](integration/README.md)如何使用，如JIRA，管理平台，LDAP和Twitter的系统集成。
- [Raketasks](raketasks/README.md)备份，维护，自动挂机网站设置和项目的进口。
- [自定义的Git挂钩](hooks/custom_hooks.md)自定义的Git挂钩（在文件系统中)的网页时，钩是不够的。
- [系统钩子](system_hooks/system_hooks.md)通知用户时，项目和键改变。
- [安全](security/README.md)了解什么可以做，以进一步保护你的GitLab实例。
- [更新](update/README.md)更新指南，升级您的安装。
- [欢迎消息](customization/welcome_message.md)添加自定义欢迎信息的登录页面。
- [发行结束](customization/issue_closing.md)自定义如何关闭的问题，从提交信息。
- [Libravatar](integration/libravatar.md)使用Libravatar用户头像。
- [操作](operations/README.md)保持GitLab启动并运行

##贡献者文档

- [发展](development/README.md)介绍架构和shell命令的指引。
- [法律](legal/README.md)提供的许可协议。
- [发行](release/README.md)如何使每月和安全释放。
