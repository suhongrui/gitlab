# -*- coding : utf-8 -*-
module AppearancesHelper
  def brand_item
    nil
  end

  def brand_title
    'Git代码库社区版'
  end

  def brand_image
    nil
  end

  def brand_text
    nil
  end
end
