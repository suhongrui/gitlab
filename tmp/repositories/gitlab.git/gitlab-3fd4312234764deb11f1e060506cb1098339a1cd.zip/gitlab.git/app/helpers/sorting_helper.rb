# -*- coding : utf-8 -*-
module SortingHelper
  def sort_title_oldest_updated
    '最早更新'
  end

  def sort_title_recently_updated
    '最近更新'
  end

  def sort_title_oldest_created
    '最早创建'
  end

  def sort_title_recently_created
    '最近创建'
  end
end
