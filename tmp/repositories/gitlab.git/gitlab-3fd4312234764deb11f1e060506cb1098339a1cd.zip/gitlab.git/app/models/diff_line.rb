class DiffLine
  attr_accessor :type, :content, :num, :code
end
