# -*- coding : utf-8 -*-
# == Schema Information
#
# Table name: services
#
#  id         :integer          not null, primary key
#  type       :string(255)
#  title      :string(255)
#  project_id :integer          not null
#  created_at :datetime
#  updated_at :datetime
#  active     :boolean          default(FALSE), not null
#  properties :text
#

class PivotaltrackerService < Service
  include HTTParty

  prop_accessor :token
  validates :token, presence: true, if: :activated?

  def title
    'PivotalTracker'
  end

  def description
    '项目管理软件（来源提交端点）'
  end

  def to_param
    'pivotaltracker'
  end

  def fields
    [
      { type: 'text', name: 'token', placeholder: '' }
    ]
  end

  def execute(push)
    url = 'https://www.pivotaltracker.com/services/v5/source_commits'
    push[:commits].each do |commit|
      message = {
        'source_commit' => {
          'commit_id' => commit[:id],
          'author' => commit[:author][:name],
          'url' => commit[:url],
          'message' => commit[:message]
        }
      }
      PivotaltrackerService.post(
        url,
        body: message.to_json,
        headers: {
          'Content-Type' => 'application/json',
          'X-TrackerToken' => token
        }
      )
    end
  end
end
