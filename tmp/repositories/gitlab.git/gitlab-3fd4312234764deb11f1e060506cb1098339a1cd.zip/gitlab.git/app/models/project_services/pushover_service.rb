# -*- coding : utf-8 -*-
# == Schema Information
#
# Table name: services
#
#  id         :integer          not null, primary key
#  type       :string(255)
#  title      :string(255)
#  project_id :integer          not null
#  created_at :datetime
#  updated_at :datetime
#  active     :boolean          default(FALSE), not null
#  properties :text
#

class PushoverService < Service
  include HTTParty
  base_uri 'https://api.pushover.net/1'

  prop_accessor :api_key, :user_key, :device, :priority, :sound
  validates :api_key, :user_key, :priority, presence: true, if: :activated?

  def title
    'Pushover'
  end

  def description
    'Pushover 可以很容易地获得实时通知您的Android设备，iPhone，iPad和 Desktop.'
  end

  def to_param
    'pushover'
  end

  def fields
    [
      { type: 'text', name: 'api_key', placeholder: '你的应用密钥' },
      { type: 'text', name: 'user_key', placeholder: '你的用户密钥' },
      { type: 'text', name: 'device', placeholder: '留空为所有有源设备' },
      { type: 'select', name: 'priority', choices:
        [
          ['最低优先级', -2],
          ['低优先级', -1],
          ['一般优先级', 0],
          ['高优先级', 1]
        ],
        default_choice: 0
      },
      { type: 'select', name: 'sound', choices:
        [
          ['设备默认的声音', nil],
          ['Pushover (默认)', 'pushover'],
          ['自行车', 'bike'],
          ['喇叭', 'bugle'],
          ['收银机', 'cashregister'],
          ['经典', 'classical'],
          ['宇宙', 'cosmic'],
          ['下降', 'falling'],
          ['网络游戏', 'gamelan'],
          ['来电', 'incoming'],
          ['中场休息', 'intermission'],
          ['魔术', 'magic'],
          ['机械', 'mechanical'],
          ['钢琴酒吧', 'pianobar'],
          ['警笛', 'siren'],
          ['航天警报', 'spacealarm'],
          ['拖船', 'tugboat'],
          ['外星警报 (长)', 'alien'],
          ['爬升 (长)', 'climb'],
          ['持续 (长)', 'persistent'],
          ['推倒回声 (长)', 'echo'],
          ['向上向下 (长)', 'updown'],
          ['无 (无声)', 'none']
        ]
      },
    ]
  end

  def execute(push_data)
    ref = push_data[:ref].gsub('refs/heads/', '')
    before = push_data[:before]
    after = push_data[:after]

    if before =~ /000000/
      message = "#{push_data[:user_name]} 推新分支 \"#{ref}\"."
    elsif after =~ /000000/
      message = "#{push_data[:user_name]} 删除分支 \"#{ref}\"."
    else
      message = "#{push_data[:user_name]} 推到分支 \"#{ref}\"."
    end

    if push_data[:total_commits_count] > 0
      message << "\n共提交数: #{push_data[:total_commits_count]}"
    end

    pushover_data = {
      token: api_key,
      user: user_key,
      device: device,
      priority: priority,
      title: "#{project.name_with_namespace}",
      message: message,
      url: push_data[:repository][:homepage],
      url_title: "参见项目 #{project.name_with_namespace}"
    }

    # Sound parameter MUST NOT be sent to API if not selected
    if sound
      pushover_data.merge!(sound: sound)
    end

    PushoverService.post('/messages.json', body: pushover_data)
  end
end
