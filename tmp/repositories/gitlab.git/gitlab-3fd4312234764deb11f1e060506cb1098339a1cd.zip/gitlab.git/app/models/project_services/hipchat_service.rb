# -*- coding : utf-8 -*-
# == Schema Information
#
# Table name: services
#
#  id         :integer          not null, primary key
#  type       :string(255)
#  title      :string(255)
#  project_id :integer          not null
#  created_at :datetime
#  updated_at :datetime
#  active     :boolean          default(FALSE), not null
#  properties :text
#

class HipchatService < Service
  MAX_COMMITS = 3

  prop_accessor :token, :room, :server
  validates :token, presence: true, if: :activated?

  def title
    'HipChat'
  end

  def description
    '私人群组聊天和即时通讯'
  end

  def to_param
    'hipchat'
  end

  def fields
    [
      { type: 'text', name: 'token',     placeholder: '' },
      { type: 'text', name: 'room',      placeholder: '' },
      { type: 'text', name: 'server',    placeholder: '留空为默认。 https://chat.hipchat.com' }
    ]
  end

  def execute(push_data)
    gate[room].send('GitLab', create_message(push_data))
  end

  private

  def gate
    options = { api_version: 'v2' }
    options[:server_url] = server unless server.nil?
    @gate ||= HipChat::Client.new(token, options)
  end

  def create_message(push)
    ref = push[:ref].gsub("refs/heads/", "")
    before = push[:before]
    after = push[:after]

    message = ""
    message << "#{push[:user_name]} "
    if before =~ /000000/
      message << "推新分支 <a href=\""\
                 "#{project.web_url}/commits/#{URI.escape(ref)}\">#{ref}</a>"\
                 " 到 <a href=\"#{project.web_url}\">"\
                 "#{project.name_with_namespace.gsub!(/\s/, "")}</a>\n"
    elsif after =~ /000000/
      message << "删除分支 #{ref} 从 <a href=\"#{project.web_url}\">#{project.name_with_namespace.gsub!(/\s/,'')}</a> \n"
    else
      message << "推到分支 <a href=\""\
                  "#{project.web_url}/commits/#{URI.escape(ref)}\">#{ref}</a> "
      message << "of <a href=\"#{project.web_url}\">#{project.name_with_namespace.gsub!(/\s/,'')}</a> "
      message << "(<a href=\"#{project.web_url}/compare/#{before}...#{after}\">变化比较</a>)"

      push[:commits].take(MAX_COMMITS).each do |commit|
        message << "<br /> - #{commit[:message].lines.first} (<a href=\"#{commit[:url]}\">#{commit[:id][0..5]}</a>)"
      end

      if push[:commits].count > MAX_COMMITS
        message << "<br />... #{push[:commits].count - MAX_COMMITS} 更多的提交"
      end
    end

    message
  end
end
