# -*- coding : utf-8 -*-
# == Schema Information
#
# Table name: services
#
#  id         :integer          not null, primary key
#  type       :string(255)
#  title      :string(255)
#  project_id :integer          not null
#  created_at :datetime
#  updated_at :datetime
#  active     :boolean          default(FALSE), not null
#  properties :text
#

class EmailsOnPushService < Service
  prop_accessor :recipients
  validates :recipients, presence: true, if: :activated?

  def title
    '推送电子邮件'
  end

  def description
    '电子邮件的提交和各推差异收件人列表。'
  end

  def to_param
    'emails_on_push'
  end

  def execute(push_data)
    EmailsOnPushWorker.perform_async(project_id, recipients, push_data)
  end

  def fields
    [
      { type: 'textarea', name: 'recipients', placeholder: '电子邮件空白隔开' },
    ]
  end
end
