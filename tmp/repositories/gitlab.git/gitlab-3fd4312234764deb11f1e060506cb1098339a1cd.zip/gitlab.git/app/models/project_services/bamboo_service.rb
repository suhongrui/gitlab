class BambooService < CiService
  include HTTParty

  prop_accessor :bamboo_url, :build_key, :username, :password

  validates :bamboo_url, presence: true,
            format: { with: URI::regexp }, if: :activated?
  validates :build_key, presence: true, if: :activated?
  validates :username, presence: true,
            if: ->(service) { service.password? }, if: :activated?
  validates :password, presence: true,
            if: ->(service) { service.username? }, if: :activated?

  attr_accessor :response

  after_save :compose_service_hook, if: :activated?

  def compose_service_hook
    hook = service_hook || build_service_hook
    hook.save
  end

  def title
    'Atlassian Bamboo CI'
  end

  def description
    '持续集成和构建服务器'
  end

  def help
    '您必须设置自动调整标签和Bamboo储存库触发。'
  end

  def to_param
    'bamboo'
  end

  def fields
    [
        { type: 'text', name: 'bamboo_url',
          placeholder: 'Bamboo 根地址像 https://bamboo.example.com' },
        { type: 'text', name: 'build_key',
          placeholder: 'Bamboo 像构建计划密钥 KEY' },
        { type: 'text', name: 'username',
          placeholder: '有API访问权限的用户（如适用）' },
        { type: 'password', name: 'password' },
    ]
  end

  def build_info(sha)
    url = URI.parse("#{bamboo_url}/rest/api/latest/result?label=#{sha}")

    if username.blank? && password.blank?
      @response = HTTParty.get(parsed_url.to_s, verify: false)
    else
      get_url = "#{url}&os_authType=basic"
      auth = {
          username: username,
          password: password,
      }
      @response = HTTParty.get(get_url, verify: false, basic_auth: auth)
    end
  end

  def build_page(sha)
    build_info(sha) if @response.nil? || !@response.code

    if @response.code != 200 || @response['results']['results']['size'] == '0'
      # If actual build link can't be determined, send user to build summary page.
      "#{bamboo_url}/browse/#{build_key}"
    else
      # If actual build link is available, go to build result page.
      result_key = @response['results']['results']['result']['planResultKey']['key']
      "#{bamboo_url}/browse/#{result_key}"
    end
  end

  def commit_status(sha)
    build_info(sha) if @response.nil? || !@response.code
    return :error unless @response.code == 200 || @response.code == 404

    status = if @response.code == 404 || @response['results']['results']['size'] == '0'
               'Pending'
             else
               @response['results']['results']['result']['buildState']
             end

    if status.include?('Success')
      'success'
    elsif status.include?('Failed')
      'failed'
    elsif status.include?('Pending')
      'pending'
    else
      :error
    end
  end

  def execute(_data)
    # Bamboo requires a GET and does not take any data.
    self.class.get("#{bamboo_url}/updateAndBuild.action?buildKey=#{build_key}",
                   verify: false)
  end
end
