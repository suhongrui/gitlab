# -*- coding : utf-8 -*-
class PostReceive
  include Sidekiq::Worker
  include Gitlab::Identifier

  sidekiq_options queue: :post_receive

  def perform(repo_path, identifier, changes)
    if repo_path.start_with?(Gitlab.config.gitlab_shell.repos_path.to_s)
      repo_path.gsub!(Gitlab.config.gitlab_shell.repos_path.to_s, "")
    else
      log("查查 gitlab.yml 配置正确 gitlab_shell.repos_path 变量. \"#{Gitlab.config.gitlab_shell.repos_path}\" 不匹配 \"#{repo_path}\"")
    end

    repo_path.gsub!(/\.git$/, "")
    repo_path.gsub!(/^\//, "")

    project = Project.find_with_namespace(repo_path)

    if project.nil?
      log("触发钩子的完整路径不存在的项目 \"#{repo_path} \"")
      return false
    end

    changes = changes.lines if changes.kind_of?(String)

    changes.each do |change|
      oldrev, newrev, ref = change.strip.split(' ')

      @user ||= identify(identifier, project, newrev)

      unless @user
        log("触发钩子非现有用户 \"#{identifier} \"")
        return false
      end

      if tag?(ref)
        GitTagPushService.new.execute(project, @user, oldrev, newrev, ref)
      else
        GitPushService.new.execute(project, @user, oldrev, newrev, ref)
      end
    end
  end

  def log(message)
    Gitlab::GitLogger.error("POST-RECEIVE: #{message}")
  end

  private

  def tag?(ref)
    !!(/refs\/tags\/(.*)/.match(ref))
  end
end
