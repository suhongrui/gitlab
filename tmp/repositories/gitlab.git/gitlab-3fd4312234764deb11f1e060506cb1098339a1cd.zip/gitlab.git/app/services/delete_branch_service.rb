# -*- coding : utf-8 -*-
require_relative 'base_service'

class DeleteBranchService < BaseService
  def execute(branch_name)
    repository = project.repository
    branch = repository.find_branch(branch_name)

    # No such branch
    unless branch
      return error('没有这样的分支', 404)
    end

    if branch_name == repository.root_ref
      return error('无法删除HEAD分支', 405)
    end

    # Dont allow remove of protected branch
    if project.protected_branch?(branch_name)
      return error('受保护的分支不能被删除', 405)
    end

    # Dont allow user to remove branch if he is not allowed to push
    unless current_user.can?(:push_code, project)
      return error('你没有推访问repo', 405)
    end

    if repository.rm_branch(branch_name)
      Event.create_ref_event(project, current_user, branch, 'rm')
      success('删除分支完成')
    else
      return error('无法删除分支')
    end
  end

  def error(message, return_code = 400)
    out = super(message)
    out[:return_code] = return_code
    out
  end

  def success(message)
    out = super()
    out[:message] = message
    out
  end
end
