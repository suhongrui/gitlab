module Milestones
  class BaseService < ::BaseService
  end
end
