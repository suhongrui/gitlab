Time.zone = Gitlab.config.gitlab.time_zone || Time.zone
