# GitLab
![标志](https://about.gituse.com/images/gitlab_logo.png)

##开源软件的代码协作

![动画截图](https://about.gituse.com/images/animated/compiled.gif)

- 管理Git仓库，使您的代码安全的细粒度访问控制
- 执行代码审查，并加强与合并请求协作
- 每个项目也可以有一个问题跟踪器和wiki
- 由超过10万的组织，GitLab是最流行的解决方案来管理本地的Git仓库
- 完全免费和开源的(MIT外籍牌照)
- 技术的Ruby on Rails

##规范源

- GitLab社区版的源[托管在GitLab.com](https://gituse.com/gitlab-org/gitlab-ce/)，并有反光镜，使[促进](CONTRIBUTING.md)一样简单可能的。

##码状态

- [![建设status](https://ci.gitlab.org/projects/1/status.png?ref=master)](https://ci.gitlab.org/projects/1?ref=master)在ci.gitlab.org(主分支)

- [![构建Status](https://semaphoreapp.com/api/v1/projects/2f1a5809-418b-4cc2-a1f4-819607579fe7/243338/badge.png)](https://semaphoreapp.com/gitlabhq/gitlabhq)

- [![代码Climate](https://codeclimate.com/github/gitlabhq/gitlabhq.svg)](https://codeclimate.com/github/gitlabhq/gitlabhq)

- [![覆盖Status](https://coveralls.io/repos/gitlabhq/gitlabhq/badge.png?branch=master)](https://coveralls.io/r/gitlabhq/gitlabhq?branch=master)

- [![PullReviewstats](https://www.pullreview.com/gitlab/gitlab-org/gitlab-ce/badges/master.svg?)](https://www.pullreview.com/gitlab.gituse.com/gitlab-org/gitlab-ce/reviews/master)

##网站

在[about.gituse.com](https://about.gituse.com/)，你可以找到更多的信息：

- [订阅](https://about.gituse.com/subscription/)
- [咨询](https://about.gituse.com/consultancy/)
- [社区](https://about.gituse.com/community/)
- [托管GitLab.com](https://about.gituse.com/gituse.com/)使用GitLab作为一项免费服务
- [GitLab企业版](https://about.gituse.com/gitlab-ee/)与旨在大型组织的附加功能。
- [GitLab Cl](https://about.gituse.com/gitlab-ci/)连续的集成(CI)的服务器，很容易与GitLab集成。

##要求

* Ubuntu/Debian**
* ruby 1.9.3
* MySQL
* git
* gitlab-shell
* redis

**更多细节在[需求文档](DOC/install/requirements.md)。

##安装

请参阅[在GitLab网站上的安装页面](https://about.gituse.com/installation/)的各种选项。
由于手动安装了大量的工作，而且容易出错，我们强烈建议您快速和可靠的[总括软件包安装](https://about.gituse.com/downloads/)(DEB/ RPM)。
您可以访问新安装的登录'root`和密码`5iveL！fe`，登录后，您需要设置一个唯一的密码。

##第三方应用程序

有很多的应用程序和API包装的GitLab。
找到他们[在我们的网站](https://about.gituse.com/applications/)。

##新版本

自2011年GitLab的或大或小版本发布在每月的22日。修补并在需要时安全发布出来。新功能进行了详细的[博客](https://about.gituse.com/blog/)和[更新日志](更新日志)。有关发行过程的详细信息请参见发行[文件](https://gituse.com/gitlab-org/gitlab-ce/tree/master/doc/release)。功能，将可能在未来的版本中可以在[功能请求论坛]被发现(http://feedback.gituse.com/forums/176466-general)的状态[开始](HTTP：//feedback.gitlab .COM/论坛/176466-一般/状态/796456)和[完成](http://feedback.gituse.com/forums/176466-general/status/796457)。

##升级

对于更新的总括安装请参阅[更新文件](https://gituse.com/gitlab-org/omnibus-gitlab/blob/master/doc/update.md)。对于手动安装有一个[升级程序脚本](DOC/更新/ upgrader.md)，并有[升级指南](DOC/更新)。

##安装一个开发环境

我们建议设置你的开发环境与[GitLab开发套件](https://gituse.com/gitlab-org/gitlab-development-kit)。
如果你不使用GitLab开发开发套件，你需要自己安装和设置所有的依赖，这是很多的工作和容易出错的。
一个很小的事情，你也有安装时自己做的是复制的例子开发麒麟配置文件：

cp config/unicorn.rb.example.development config/unicorn.rb

关于如何启动Gitlab以及如何运行测试的说明可以在[发展GitLab开发工具包的部分]中找到(https://gituse.com/gitlab-org/gitlab-development-kit#development)。

##文档

所有文件可以在[doc.gituse.com/ce/](http://doc.gituse.com/ce/找到)。

##获得帮助

请参阅我们的网站上[获取帮助GitLab](https://about.gituse.com/getting-help/)的许多选项来获得帮助。

##是什么好？

[是](https://news.ycombinator.com/item?id=3067434)

##是它真棒？

谢谢[问这个问题](https://twitter.com/supersloth/status/489462789384056832)约书亚。
[这些人](https://twitter.com/gitlab/favorites)似乎喜欢它。